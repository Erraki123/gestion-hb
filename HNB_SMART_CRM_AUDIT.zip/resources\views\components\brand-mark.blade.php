<svg {{ $attributes }} viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <rect width="64" height="64" rx="14" fill="#C9A227"/>
    <rect x="15" y="34" width="9" height="14" rx="2" fill="#121211"/>
    <rect x="27.5" y="25" width="9" height="23" rx="2" fill="#121211"/>
    <rect x="40" y="14" width="9" height="34" rx="2" fill="#121211"/>
</svg>
